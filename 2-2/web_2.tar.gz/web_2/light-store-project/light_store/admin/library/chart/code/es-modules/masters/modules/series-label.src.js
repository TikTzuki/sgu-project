/**
 * @license Highcharts JS v8.1.1 (2020-06-09)
 * @module highcharts/modules/series-label
 * @requires highcharts
 *
 * (c) 2009-2019 Torstein Honsi
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../modules/series-label.src.js';
