/**
 * @license Highcharts JS v8.1.1 (2020-06-09)
 * @module highcharts/modules/windbarb
 * @requires highcharts
 *
 * Wind barb series module
 *
 * (c) 2010-2019 Torstein Honsi
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../modules/windbarb.src.js';
