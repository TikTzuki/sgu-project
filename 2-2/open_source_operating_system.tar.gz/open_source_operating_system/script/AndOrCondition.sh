[ 10 -gt 11 ] &&  echo "Hello" || echo "World" ||echo "Hello World"
