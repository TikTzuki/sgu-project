#!/bin/bash
clear
read -p "Please enter a number: " num

echo "\nYour number in reverse order: `echo $num | rev`.\n"