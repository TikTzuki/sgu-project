#!/bin/bash
echo "Today is: `date`"
echo "Hello $LOGNAME !!!"
echo "Your current working directory: $PWD"
echo "Your home directory: $HOME"
read -p "Please press enter to finish: "
echo "Thank you very much!!"
